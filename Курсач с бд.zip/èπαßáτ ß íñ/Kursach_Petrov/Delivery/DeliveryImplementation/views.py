from django.shortcuts import render
from django.views.generic import ListView
from .models import Post


def index(request):
    return render(request, '../template/index.html')

def regPageView(request):
    return render(request, "../template/registration/registration.html")

def loginPageView(request):
    return render(request, "../template/registration/login.html")